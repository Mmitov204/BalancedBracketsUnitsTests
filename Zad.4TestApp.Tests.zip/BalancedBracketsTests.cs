﻿using System;
using NUnit.Framework;

namespace TestApp.Tests;

public class BalancedBracketsTests
{
    [Test]//1
    public void Test_IsBalanced_EmptyInput_ShouldReturnTrue()
    {
        //Arrange
        string[] EmptyInput = new string[] { };
        //Act
        bool result = BalancedBrackets.IsBalanced(EmptyInput);
        //Assert
        Assert.IsTrue(result);

    }

    [Test]//2
    public void Test_IsBalanced_BalancedBrackets_ShouldReturnTrue()
    {
        //Arrange
        string[] Input = new string[] { "(", ")", "(", ")" };
        //Act
        bool result = BalancedBrackets.IsBalanced(Input);
        //Assert
        Assert.IsTrue(result);
    }

    [Test]//3
    public void Test_IsBalanced_UnbalancedBrackets_ShouldReturnFalse()
    {
        //Arrange
        string[] UnbalancedInput = new string[] { "(", ")", ")", ")" };
        //Act
        bool result = BalancedBrackets.IsBalanced(UnbalancedInput);
        //Assert
        Assert.IsFalse(result);
    }

    [Test]//4
    public void Test_IsBalanced_MoreClosingBrackets_ShouldReturnFalse()
    {
        //Arrange
        string[] UnbalancedInput = new string[] { "(", ")", ")", ")",")" };
        //Act
        bool result = BalancedBrackets.IsBalanced(UnbalancedInput);
        //Assert
        Assert.IsFalse(result);
    }

    [Test]//5
    public void Test_IsBalanced_NoClosingBrackets_ShouldReturnFalse()
    {
        //Arrange
        string[] UnbalancedInput = new string[] { "(", "(", "(", "(", "(" };
        //Act
        bool result = BalancedBrackets.IsBalanced(UnbalancedInput);
        //Assert
        Assert.IsFalse(result);
    }
}
